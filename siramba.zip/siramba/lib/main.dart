import 'dart:math';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'dart:async';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (Firebase.apps.isEmpty) {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } else {
    Firebase.app();
  }

  runApp(const MyApp());
}

// ===================== MYAPP (LIGHT THEME ONLY) ======================
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SIRAMBA',
      theme: ThemeData(
        brightness: Brightness.light, // ✅ selalu terang
        primarySwatch: Colors.blue,
        fontFamily: 'Poppins',
      ),
      home: const SplashPage(),
    );
  }
}

// ===================== SPLASH PAGE (tanpa dark mode) ======================
class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _pulseAnimation;
  late Animation<Alignment> _gradientAnimation;

  final int _particleCount = 50;
  final Random _random = Random();
  late List<Offset> _particlePositions;
  late List<double> _particleSizes;
  late List<double> _particleSpeeds;

  @override
  void initState() {
    super.initState();

    _controller =
        AnimationController(vsync: this, duration: const Duration(seconds: 3))
          ..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 0.8, end: 1.2).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _gradientAnimation =
        AlignmentTween(begin: Alignment.topLeft, end: Alignment.bottomRight)
            .animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _particlePositions = List.generate(
      _particleCount,
      (index) => Offset(_random.nextDouble(), _random.nextDouble()),
    );

    _particleSizes =
        List.generate(_particleCount, (index) => _random.nextDouble() * 4 + 1);
    _particleSpeeds =
        List.generate(_particleCount, (index) => _random.nextDouble() * 0.003 + 0.001);

    // Navigasi ke MonitorPage setelah 6 detik
    Future.delayed(const Duration(seconds: 6), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const MonitorPage()),
      );
    });

    _controller.addListener(() {
      setState(() {
        for (int i = 0; i < _particleCount; i++) {
          double dx = _particlePositions[i].dx + _particleSpeeds[i];
          double dy = _particlePositions[i].dy + _particleSpeeds[i] / 2;
          if (dx > 1) dx = 0;
          if (dy > 1) dy = 0;
          _particlePositions[i] = Offset(dx, dy);
        }
      });
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Widget _buildParticles(Size size) {
    return Stack(
      children: List.generate(_particleCount, (i) {
        final pos = _particlePositions[i];
        final x = pos.dx * size.width;
        final y = pos.dy * size.height;
        final radius = _particleSizes[i];
        return Positioned(
          left: x,
          top: y,
          child: Container(
            width: radius,
            height: radius,
            decoration: BoxDecoration(
              // ignore: deprecated_member_use
              color: Colors.blue.shade200.withOpacity(0.7),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  // ignore: deprecated_member_use
                  color: Colors.blue.shade100.withOpacity(0.5),
                  blurRadius: 4,
                  spreadRadius: 1,
                )
              ],
            ),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Scaffold(
          body: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: _gradientAnimation.value,
                end: Alignment.bottomRight,
                colors: [
                  Colors.blue.shade900,
                  Colors.blue.shade600,
                  Colors.blue.shade400,
                ],
              ),
            ),
            child: Stack(
              children: [
                _buildParticles(size),
                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Transform.scale(
                        scale: _pulseAnimation.value,
                        child: Icon(
                          Icons.eco,
                          color: Colors.blue.shade100,
                          size: 100,
                        ),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        "SIRAMBA",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        "Smart Garden IoT System",
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 16,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                      const SizedBox(height: 40),
                      const CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ===================== MONITOR PAGE (tanpa dark mode) ======================
class MonitorPage extends StatefulWidget {
  const MonitorPage({super.key});

  @override
  State<MonitorPage> createState() => _MonitorPageState();
}

class _MonitorPageState extends State<MonitorPage> {
  final sensorRef = FirebaseDatabase.instance.ref('sensor');
  final controlRef = FirebaseDatabase.instance.ref('control');
  final historyRef = FirebaseDatabase.instance.ref('history');

  bool isAuto = true;
  String pompaStatus = 'OFF';
  String statusTanaman = 'Unknown'; // 🔥 Tambahkan status tanaman
  bool isManualSiramActive = false;
  Timer? historyTimer;
  late String lastPompaStatus;
  int pompaDurasi = 30; // 🔥 Durasi default 30 detik

  @override
  void initState() {
    super.initState();
    lastPompaStatus = 'OFF';

    // 🔥 Baca mode awal dari Firebase
    _loadInitialMode();

    historyTimer = Timer.periodic(const Duration(minutes: 1), (_) {
      if (mounted) _saveToHistory();
    });

    sensorRef.onValue.listen((event) {
      final data = Map<String, dynamic>.from(event.snapshot.value as Map? ?? {});
      final currentPompa = data['Pompa']?.toString() ?? 'OFF';
      final currentStatus = data['Status']?.toString() ?? 'Unknown'; // 🔥 Ambil status tanaman

      if (currentPompa != lastPompaStatus) {
        lastPompaStatus = currentPompa;
        if (!isManualSiramActive && mounted) {
          setState(() {
            pompaStatus = currentPompa;
          });
        }
        if (mounted) _saveToHistory();
      }

      // 🔥 Update status tanaman jika berubah
      if (currentStatus != statusTanaman && mounted) {
        setState(() {
          statusTanaman = currentStatus;
        });
      }
    });

    // 🔥 Baca durasi pompa dari Firebase
    controlRef.onValue.listen((event) {
      final data = Map<String, dynamic>.from(event.snapshot.value as Map? ?? {});
      final durasi = data['pompa_durasi'] ?? 30;
      if (durasi != pompaDurasi && mounted) {
        setState(() {
          pompaDurasi = durasi is int ? durasi : 30;
        });
      }
    });
  }

  // 🔥 Muat mode awal dari Firebase
  Future<void> _loadInitialMode() async {
    try {
      final snapshot = await controlRef.get();
      if (snapshot.exists) {
        final data = Map<String, dynamic>.from(snapshot.value as Map);
        final mode = data['Mode'] == true;
        if (mounted) {
          setState(() {
            isAuto = mode;
          });
        }
      }
    } catch (e) {
      debugPrint("Gagal memuat mode awal: $e");
    }
  }

  @override
  void dispose() {
    historyTimer?.cancel();
    super.dispose();
  }

  // ===================== WARNA =====================
  Color _getSuhuColor(double s) {
    if (s > 35) return Colors.redAccent;
    if (s > 28) return Colors.orangeAccent;
    return Colors.green;
  }

  Color _getKelembapanColor(double h) {
    if (h < 30) return Colors.redAccent;
    if (h < 60) return Colors.orangeAccent;
    return Colors.blueAccent;
  }

  // 🔥 Warna status tanaman
  Color _getStatusColor(String status) {
    switch (status) {
      case 'Normal':
        return Colors.green;
      case 'Kekeringan':
        return Colors.red;
      case 'Terlalu Panas':
        return Colors.orange;
      case 'Terlalu Lembab':
        return Colors.blue;
      case 'Kritis!':
        return Colors.red.shade900;
      default:
        return Colors.grey;
    }
  }

  // 🔥 Ikon status tanaman
  IconData _getStatusIcon(String status) {
    switch (status) {
      case 'Normal':
        return Icons.sentiment_very_satisfied;
      case 'Kekeringan':
        return Icons.local_florist_outlined;
      case 'Terlalu Panas':
        return Icons.thermostat_auto;
      case 'Terlalu Lembab':
        return Icons.opacity;
      case 'Kritis!':
        return Icons.report_problem;
      default:
        return Icons.help_outline;
    }
  }

  // ===================== TOGGLE MODE =====================
  Future<void> _toggleMode(bool value) async {
    setState(() => isAuto = value);
    try {
      await controlRef.update({'Mode': isAuto});
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(isAuto
              ? '🔄 Mode Otomatis diaktifkan'
              : '⚙ Mode Manual diaktifkan'),
          duration: const Duration(seconds: 2),
        ));
      }
    } catch (e) {
      setState(() => isAuto = !value);
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Gagal mengubah mode: $e')));
      }
    }
  }

  // ===================== TOMBOL SIRAM =====================
  Future<void> _triggerSiram() async {
    if (isManualSiramActive || isAuto) return;

    setState(() {
      isManualSiramActive = true;
      pompaStatus = "ON";
    });

    await _saveToHistory();

    try {
      await controlRef.update({'siram': true});
      await Future.delayed(Duration(seconds: pompaDurasi)); // 🔥 Gunakan durasi dinamis

      final snapshot = await sensorRef.get();
      if (snapshot.exists) {
        final data = Map<String, dynamic>.from(snapshot.value as Map);
        final pompa = data['Pompa']?.toString() ?? 'OFF';
        if (mounted) {
          setState(() {
            pompaStatus = pompa;
            isManualSiramActive = false;
          });
          await _saveToHistory();
        }
      } else {
        if (mounted) {
          setState(() {
            pompaStatus = "OFF";
            isManualSiramActive = false;
          });
          await _saveToHistory();
        }
      }
    } catch (e) {
      if (mounted) setState(() => isManualSiramActive = false);
      debugPrint("Error saat men-trigger siram: $e");
    }
  }

  // ===================== SET DURASI POMPA =====================
  Future<void> _setPompaDurasi(int durasi) async {
    try {
      await controlRef.update({'pompa_durasi': durasi});
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Durasi pompa diubah menjadi $durasi detik'),
          duration: const Duration(seconds: 2),
        ));
      }
    } catch (e) {
      debugPrint("Gagal mengubah durasi pompa: $e");
    }
  }

  // ===================== SIMPAN KE HISTORY =====================
  Future<void> _saveToHistory() async {
    final snapshot = await sensorRef.get();
    if (!snapshot.exists) return;

    final data = Map<String, dynamic>.from(snapshot.value as Map);
    final suhu = double.tryParse(data['Suhu']?.toString() ?? '0') ?? 0;
    final suhuTanah = double.tryParse(data['SuhuTanah']?.toString() ?? '0') ?? 0;
    final kelembapanTanah = double.tryParse(data['KelembapanTanah']?.toString() ?? '0') ?? 0;
    final kelembapanUdara = double.tryParse(data['KelembapanUdara']?.toString() ?? '0') ?? 0;
    final mode = data['Mode'] == true;
    final pompa = data['Pompa']?.toString() ?? 'OFF';
    final status = data['Status']?.toString() ?? 'Unknown'; // 🔥 Ambil status

    await historyRef.push().set({
      'Suhu': suhu,
      'SuhuTanah': suhuTanah,
      'KelembapanTanah': kelembapanTanah,
      'KelembapanUdara': kelembapanUdara,
      'Mode': mode,
      'Pompa': pompa,
      'Status': status, // 🔥 Simpan status tanaman ke history
      'pompa_durasi': pompaDurasi, // 🔥 Simpan durasi pompa ke history
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    });
  }

  // ===================== UI =====================
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final width = size.width;
    final height = size.height;
    final isLargeScreen = width > 1000;
    final cardWidth = isLargeScreen ? width * 0.28 : width * 0.43; // Diubah agar 2 kolom di layar kecil
    final fontScale = isLargeScreen ? 1.3 : 1.0;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Smart Garden Monitor"),
        backgroundColor: const Color(0xFF2980B9),
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const HistoryPage()),
              );
            },
          ),
          // ✅ Tidak ada switch dark mode
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF6DD5FA), Color(0xFF2980B9)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: StreamBuilder(
            stream: controlRef.onValue,
            builder: (context, controlSnap) {
              if (controlSnap.hasData && controlSnap.data!.snapshot.value != null) {
                final data = Map<String, dynamic>.from(controlSnap.data!.snapshot.value as Map);
                final firebaseMode = data['Mode'] == true;
                if (firebaseMode != isAuto) {
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    if (mounted) setState(() => isAuto = firebaseMode);
                  });
                }
              }

              return StreamBuilder(
                stream: sensorRef.onValue,
                builder: (context, snapshot) {
                  double suhu = 0;
                  double suhuTanah = 0;
                  double kelembapanTanah = 0;
                  double kelembapanUdara = 0;

                  if (snapshot.hasData && snapshot.data!.snapshot.value != null) {
                    final data = Map<String, dynamic>.from(snapshot.data!.snapshot.value as Map);
                    suhu = double.tryParse(data['Suhu']?.toString() ?? '0') ?? 0;
                    suhuTanah = double.tryParse(data['SuhuTanah']?.toString() ?? '0') ?? 0;
                    kelembapanTanah = double.tryParse(data['KelembapanTanah']?.toString() ?? '0') ?? 0;
                    kelembapanUdara = double.tryParse(data['KelembapanUdara']?.toString() ?? '0') ?? 0;
                    final firebasePompa = data['Pompa']?.toString() ?? 'OFF';
                    final firebaseStatus = data['Status']?.toString() ?? 'Unknown'; // 🔥 Ambil status dari Firebase
                    if (!isManualSiramActive) pompaStatus = firebasePompa;
                    statusTanaman = firebaseStatus; // 🔥 Update status tanaman
                  }

                  return Center(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: EdgeInsets.symmetric(
                        horizontal: width * 0.04,
                        vertical: height * 0.04,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            'Smart Monitoring Bawang Merah',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 28 * fontScale,
                              fontWeight: FontWeight.bold,
                              shadows: const [
                                Shadow(color: Colors.black45, blurRadius: 8),
                              ],
                            ),
                            textAlign: TextAlign.center,
                          ),
                          SizedBox(height: height * 0.04),

                          // 🔥 GRID 2 KOLom untuk 6 sensor card - dengan jarak lebih renggang
                          SizedBox(
                            width: double.infinity,
                            child: Wrap(
                              spacing: 20, // jarak horizontal antar card
                              runSpacing: 30, // jarak vertikal antar row
                              alignment: WrapAlignment.center,
                              children: [
                                _buildInfoCard(
                                  title: "Status Tanaman",
                                  value: statusTanaman,
                                  icon: _getStatusIcon(statusTanaman), // Gunakan ikon dinamis
                                  color: _getStatusColor(statusTanaman),
                                  width: cardWidth,
                                  fontScale: fontScale,
                                ),
                                _buildInfoCard(
                                  title: "Kelembapan Tanah",
                                  value: "${kelembapanTanah.toStringAsFixed(1)} %",
                                  icon: Icons.opacity, // Ganti
                                  color: _getKelembapanColor(kelembapanTanah),
                                  width: cardWidth,
                                  fontScale: fontScale,
                                ),
                                _buildInfoCard(
                                  title: "Kelembapan Udara",
                                  value: "${kelembapanUdara.toStringAsFixed(1)} %",
                                  icon: Icons.air_outlined, // Ganti
                                  color: _getKelembapanColor(kelembapanUdara),
                                  width: cardWidth,
                                  fontScale: fontScale,
                                ),
                                _buildInfoCard(
                                  title: "Suhu Udara",
                                  value: "${suhu.toStringAsFixed(1)} °C",
                                  icon: Icons.thermostat,
                                  color: _getSuhuColor(suhu),
                                  width: cardWidth,
                                  fontScale: fontScale,
                                ),
                                _buildInfoCard(
                                  title: "Suhu Tanah",
                                  value: "${suhuTanah.toStringAsFixed(1)} °C",
                                  icon: Icons.terrain, // Ganti
                                  color: _getSuhuColor(suhuTanah),
                                  width: cardWidth,
                                  fontScale: fontScale,
                                ),
                                _buildInfoCard(
                                  title: "Status Pompa",
                                  value: pompaStatus,
                                  icon: pompaStatus == "ON"
                                      ? Icons.plumbing // Ganti
                                      : Icons.plumbing_outlined, // Ganti
                                  color: pompaStatus == "ON" ? Colors.green : Colors.redAccent,
                                  width: cardWidth,
                                  fontScale: fontScale,
                                ),
                              ],
                            ),
                          ),

                          SizedBox(height: height * 0.05),
                          ModeSiramCard(
                            isAuto: isAuto,
                            isManualSiramActive: isManualSiramActive,
                            fontScale: fontScale,
                            onModeChange: _toggleMode,
                            onTriggerSiram: _triggerSiram,
                          ),
                          // 🔥 Tambahkan tombol durasi
                          const SizedBox(height: 10),
                          DurasiPompaCard(
                            currentDurasi: pompaDurasi,
                            onDurasiChange: _setPompaDurasi,
                          ),
                          const SizedBox(height: 25),
                          Text(
                            '🔥 Data realtime dari Firebase',
                            style: TextStyle(
                              color: Colors.black54,
                              fontSize: 16 * fontScale,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildInfoCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
    required double width,
    required double fontScale,
  }) {
    return Container(
      margin: const EdgeInsets.all(4), // Agar tetap rapi di grid
      width: width,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(24),
          onTap: () {}, // Bisa dikembangkan nanti (misal: grafik detail)
          child: Ink(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  // ignore: deprecated_member_use
                  Colors.white.withOpacity(0.9),
                  // ignore: deprecated_member_use
                  Colors.white.withOpacity(0.75),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  // ignore: deprecated_member_use
                  color: color.withOpacity(0.15),
                  blurRadius: 12,
                  offset: const Offset(0, 6),
                ),
                BoxShadow(
                  // ignore: deprecated_member_use
                  color: Colors.blueGrey.withOpacity(0.05),
                  blurRadius: 2,
                  offset: const Offset(0, 2),
                ),
              ],
              // ignore: deprecated_member_use
              border: Border.all(color: color.withOpacity(0.3), width: 1.5),
            ),
            child: Padding(
              padding: EdgeInsets.symmetric(
                vertical: 20 * fontScale,
                horizontal: 24 * fontScale,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    icon,
                    size: 56 * fontScale,
                    color: color,
                  ),
                  const SizedBox(height: 14),
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 20 * fontScale,
                      fontWeight: FontWeight.w600,
                      color: Colors.grey[700],
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 10),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 400),
                    transitionBuilder: (child, anim) => FadeTransition(
                      opacity: anim,
                      child: ScaleTransition(scale: anim, child: child),
                    ),
                    child: Text(
                      value,
                      key: ValueKey(value),
                      style: TextStyle(
                        fontSize: 32 * fontScale,
                        fontWeight: FontWeight.bold,
                        color: color,
                        height: 1.1,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ========================== Mode & Siram Card ==========================
class ModeSiramCard extends StatefulWidget {
  final bool isAuto;
  final bool isManualSiramActive;
  final Function(bool) onModeChange;
  final Future<void> Function() onTriggerSiram;
  final double fontScale;

  const ModeSiramCard({
    super.key,
    required this.isAuto,
    required this.isManualSiramActive,
    required this.onModeChange,
    required this.onTriggerSiram,
    required this.fontScale,
  });

  @override
  State<ModeSiramCard> createState() => _ModeSiramCardState();
}

class _ModeSiramCardState extends State<ModeSiramCard>
    with SingleTickerProviderStateMixin {
  late bool localIsAuto;
  late bool localSiramActive;
  late AnimationController _buttonScaleController;
  late Animation<double> _buttonScale;

  @override
  void initState() {
    super.initState();
    localIsAuto = widget.isAuto;
    localSiramActive = widget.isManualSiramActive;
    _buttonScaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );
    _buttonScale = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _buttonScaleController, curve: Curves.easeInOut),
    );
  }

  @override
  void didUpdateWidget(covariant ModeSiramCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    localIsAuto = widget.isAuto;
    localSiramActive = widget.isManualSiramActive;
  }

  @override
  void dispose() {
    _buttonScaleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFF0F4FF), Color(0xFFE6EDFF)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            // ignore: deprecated_member_use
            color: Colors.blue.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
        // ignore: deprecated_member_use
        border: Border.all(color: Colors.blue.withOpacity(0.2), width: 1),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Mode Label & Switch
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  localIsAuto ? "Mode Otomatis" : "Mode Manual",
                  style: TextStyle(
                    fontSize: 20 * widget.fontScale,
                    fontWeight: FontWeight.bold,
                    color: localIsAuto ? Colors.green : Colors.orange,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Text(
                      localIsAuto
                          ? "Sistem mengatur siram otomatis"
                          : "Kontrol manual aktif",
                      style: TextStyle(
                        fontSize: 14 * widget.fontScale,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Switch(
            value: localIsAuto,
            activeColor: Colors.green,
            // ignore: deprecated_member_use
            activeTrackColor: Colors.green.withOpacity(0.3),
            inactiveThumbColor: Colors.orange,
            // ignore: deprecated_member_use
            inactiveTrackColor: Colors.orange.withOpacity(0.3),
            onChanged: (v) async {
              setState(() => localIsAuto = v);
              await widget.onModeChange(v);
            },
          ),
          const SizedBox(width: 12),
          // Tombol Siram
          AnimatedBuilder(
            animation: _buttonScaleController,
            builder: (context, child) {
              return Transform.scale(
                scale: _buttonScale.value,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: localIsAuto || localSiramActive
                        ? Colors.grey[400]
                        : const Color(0xFF2980B9),
                    padding: EdgeInsets.symmetric(
                      vertical: 14 * widget.fontScale,
                      horizontal: 24 * widget.fontScale,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    elevation: localIsAuto || localSiramActive ? 2 : 6,
                    shadowColor:
                        localIsAuto || localSiramActive ? null : Colors.blue,
                  ),
                  onPressed: localIsAuto || localSiramActive
                      ? null
                      : () async {
                          _buttonScaleController.forward();
                          await Future.delayed(const Duration(milliseconds: 100));
                          _buttonScaleController.reverse();
                          setState(() => localSiramActive = true);
                          await widget.onTriggerSiram();
                          if (mounted) setState(() => localSiramActive = false);
                        },
                  icon: Icon(
                    Icons.water_drop,
                    color: Colors.white,
                    size: 24,
                  ),
                  label: Text(
                    localSiramActive ? "Menyiram..." : "Siram Sekarang",
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

// ========================== DURASI POMPA CARD ==========================
class DurasiPompaCard extends StatefulWidget {
  final int currentDurasi;
  final Function(int) onDurasiChange;

  const DurasiPompaCard({
    super.key,
    required this.currentDurasi,
    required this.onDurasiChange,
  });

  @override
  State<DurasiPompaCard> createState() => _DurasiPompaCardState();
}

class _DurasiPompaCardState extends State<DurasiPompaCard> {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFE8F4FD), Color(0xFFD1E7F5)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            // ignore: deprecated_member_use
            // ignore: deprecated_member_use
            // ignore: deprecated_member_use
            color: Colors.blue.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
        // ignore: deprecated_member_use
        border: Border.all(color: Colors.blue.withOpacity(0.2), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Durasi Siram',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.blue[800],
            ),
          ),
          const SizedBox(height: 10),
          Text(
            'Atur berapa lama pompa menyala (detik)',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              // 🔥 GANTI BARIS INI: Ubah durasi dari detik ke menit (dalam detik)
              _buildDurasiButton(180), // 3 menit
              _buildDurasiButton(300), // 5 menit
              _buildDurasiButton(420), // 7 menit
              _buildDurasiButton(600), // 10 menit
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Durasi aktif: ${widget.currentDurasi} detik',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.blue[700],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDurasiButton(int durasi) {
    // 🔥 GANTI LABEL: Tampilkan dalam menit
    String label = '';
    if (durasi == 180) {
      label = '3 m';
    } else if (durasi == 300) {
      label = '5 m';
    } else if (durasi == 420) {
      label = '7 m';
    } else if (durasi == 600) {
      label = '10 m';
    } else {
      label = '$durasi s'; // Fallback jika durasi custom
    }

    return FilterChip(
      label: Text(label),
      selected: widget.currentDurasi == durasi,
      onSelected: (selected) {
        if (selected) {
          widget.onDurasiChange(durasi);
        }
      },
      selectedColor: Colors.blue,
      checkmarkColor: Colors.white,
      labelStyle: TextStyle(
        color: widget.currentDurasi == durasi ? Colors.white : Colors.blue,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(
          color: widget.currentDurasi == durasi ? Colors.blue : Colors.grey,
        ),
      ),
    );
  }
}

// ========================== HISTORY PAGE ==========================
class HistoryPage extends StatelessWidget {
  const HistoryPage({super.key});

  @override
  Widget build(BuildContext context) {
    final historyRef = FirebaseDatabase.instance.ref('history');

    return Scaffold(
      appBar: AppBar(title: const Text("History Data")),
      body: StreamBuilder(
        stream: historyRef.orderByChild('timestamp').onValue,
        builder: (context, snapshot) {
          if (!snapshot.hasData || snapshot.data!.snapshot.value == null) {
            return const Center(child: Text("No history data"));
          }

          final map = Map<String, dynamic>.from(snapshot.data!.snapshot.value as Map);
          final list = map.entries.toList()
            ..sort((a, b) => (b.value['timestamp'] as int).compareTo(a.value['timestamp'] as int));

          return ListView.builder(
            itemCount: list.length,
            itemBuilder: (context, index) {
              final entry = Map<String, dynamic>.from(list[index].value);
              final date = DateTime.fromMillisecondsSinceEpoch(entry['timestamp'] ?? 0);
              final durasi = entry['pompa_durasi'] ?? 'N/A';
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: ListTile(
                  title: Text("Pompa: ${entry['Pompa']}, Mode: ${entry['Mode'] ? "Auto" : "Manual"}"),
                  subtitle: Text(
                      "Durasi: $durasi s, Status: ${entry['Status']}, Suhu: ${entry['Suhu']}°C, Suhu Tanah: ${entry['SuhuTanah']}°C, Kelembapan Udara: ${entry['KelembapanUdara']}%, Kelembapan Tanah: ${entry['KelembapanTanah']}%\n${date.toLocal()}"),
                ),
              );
            },
          );
        },
      ),
    );
  }
}