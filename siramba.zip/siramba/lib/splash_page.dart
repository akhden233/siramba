import 'dart:math';
import 'package:flutter/material.dart';
import 'main.dart';

class SplashPage extends StatefulWidget {
  final bool isDarkMode;
  final void Function(bool) toggleDarkMode;

  const SplashPage({
    super.key,
    required this.isDarkMode,
    required this.toggleDarkMode,
  });

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _pulseAnimation;
  late Animation<Alignment> _gradientAnimation;
  late Animation<Offset> _slideText1;
  late Animation<Offset> _slideText2;

  final int _particleCount = 50;
  final Random _random = Random();
  late List<Offset> _particlePositions;
  late List<double> _particleSizes;
  late List<double> _particleSpeeds;

  @override
  void initState() {
    super.initState();

    _controller =
        AnimationController(vsync: this, duration: const Duration(seconds: 3))
          ..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 0.8, end: 1.2).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _gradientAnimation =
        AlignmentTween(begin: Alignment.topLeft, end: Alignment.bottomRight)
            .animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _slideText1 = Tween<Offset>(
            begin: const Offset(0, 0.5), end: Offset.zero)
        .animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );

    _slideText2 = Tween<Offset>(
            begin: const Offset(0, 0.8), end: Offset.zero)
        .animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );

    _particlePositions = List.generate(
      _particleCount,
      (index) => Offset(_random.nextDouble(), _random.nextDouble()),
    );

    _particleSizes =
        List.generate(_particleCount, (index) => _random.nextDouble() * 4 + 1);
    _particleSpeeds =
        List.generate(_particleCount, (index) => _random.nextDouble() * 0.003 + 0.001);

    // Navigasi ke MonitorPage setelah 6 detik
    Future.delayed(const Duration(seconds: 6), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => MonitorPage(
          ),
        ),
      );
    });

    // Update particle positions tiap frame
    _controller.addListener(() {
      setState(() {
        for (int i = 0; i < _particleCount; i++) {
          double dx = _particlePositions[i].dx + _particleSpeeds[i];
          double dy = _particlePositions[i].dy + _particleSpeeds[i] / 2;
          if (dx > 1) dx = 0;
          if (dy > 1) dy = 0;
          _particlePositions[i] = Offset(dx, dy);
        }
      });
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Widget _buildParticles(Size size) {
    return Stack(
      children: List.generate(_particleCount, (i) {
        final pos = _particlePositions[i];
        final x = pos.dx * size.width;
        final y = pos.dy * size.height;
        final radius = _particleSizes[i];
        return Positioned(
          left: x,
          top: y,
          child: Container(
            width: radius,
            height: radius,
            decoration: BoxDecoration(
              // ignore: deprecated_member_use
              color: Colors.blue.shade200.withOpacity(0.7),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  // ignore: deprecated_member_use
                  color: Colors.blue.shade100.withOpacity(0.5),
                  blurRadius: 4,
                  spreadRadius: 1,
                )
              ],
            ),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Scaffold(
          body: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: _gradientAnimation.value,
                end: Alignment.bottomRight,
                colors: [
                  Colors.blue.shade900,
                  Colors.blue.shade600,
                  Colors.blue.shade400,
                ],
              ),
            ),
            child: Stack(
              children: [
                _buildParticles(size),
                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Transform.scale(
                        scale: _pulseAnimation.value,
                        child: Icon(
                          Icons.eco,
                          color: Colors.blue.shade100,
                          size: 100,
                        ),
                      ),
                      const SizedBox(height: 20),
                      SlideTransition(
                        position: _slideText1,
                        child: Text(
                          "SIRAMBA",
                          style: TextStyle(
                            color: Colors.blue.shade50,
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      SlideTransition(
                        position: _slideText2,
                        child: Text(
                          "Smart Monitoring Bawang Merah IoT System",
                          style: TextStyle(
                            // ignore: deprecated_member_use
                            color: Colors.blue.shade100.withOpacity(0.9),
                            fontSize: 16,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      ),
                      const SizedBox(height: 40),
                      CircularProgressIndicator(
                        valueColor:
                            AlwaysStoppedAnimation<Color>(Colors.blue.shade100),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
